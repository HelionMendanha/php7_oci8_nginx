#!/bin/bash

INSTALL_DIR=`dirname $0`

if hash php 2>/dev/null; then
    # We need this hack because php-config is shipped in php5-dev pkg
    EXTENSION_DIR=`php -r 'echo ini_get("extension_dir");'`
    PHP_MAJOR_VERSION=`php -r 'echo PHP_MAJOR_VERSION;'`
    PHP_MINOR_VERSION=`php -r 'echo PHP_MINOR_VERSION;'`
    PHP_VERSION="${PHP_MAJOR_VERSION}.${PHP_MINOR_VERSION}";

    echo "Detected PHP ${PHP_VERSION} and extension directory: ${EXTENSION_DIR}"
else
    echo "No PHP installation found.";
    echo "Symlink the tideways.so extension";
    echo "for your PHP version into your extension directory."
    echo "Files have been installed to:"
    echo ""
    echo "  $INSTALL_DIR"
    exit 1
fi

if [ -d "/opt/plesk/php" ]; then
    echo "Detected Plesk PHP and installing Tideways for Plesk"

    VERSIONS=( "5.6" "7.0" "7.1" "7.2" "7.3" "7.4" "8.0" )
    for VERSION in "${VERSIONS[@]}"
    do
        if [ -d "/opt/plesk/php/${VERSION}/lib/php/modules" ]; then
            EXTENSION_DIR="/opt/plesk/php/${VERSION}/lib/php/modules"
            CONFIG_DIR="/opt/plesk/php/${VERSION}/etc/php.d"

            ln -sf "$INSTALL_DIR/tideways-php-${VERSION}.so" "${EXTENSION_DIR}/tideways.so"

            echo "- Detected PHP ${VERSION} and extension directory: ${EXTENSION_DIR}"

            if [ ! -f "${CONFIG_DIR}/tideways.ini" ]; then
                cp $INSTALL_DIR/tideways.ini $CONFIG_DIR/tideways.ini
            fi
        fi
    done

    echo ""
fi

EXTENSION_FILE="$INSTALL_DIR/tideways-php-${PHP_VERSION}.so"

if [ -f "$EXTENSION_FILE" ]; then
    echo "Installing into $EXTENSION_DIR"
    cp $EXTENSION_FILE $EXTENSION_DIR/tideways.so

    echo "Please add the following line to your php.ini file:"
    echo ""
    echo "extension=tideways.so"
    echo ""
    echo "Please restart any webserver or php-fpm process afterwards to make the extension available."
    exit 0
else
    echo "No Tideways Profiler binary found for PHP version ${PHP_VERSION}."
    echo "Please contact support@tideways.com if you need help."
    exit 3
fi
